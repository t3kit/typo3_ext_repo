
#### v1.0.1 `July 8, 2016`
- **[DOC]** add license file (Podio feature_24) ([ac1242a](https://github.com/t3kit/t3kit_extension_tools/commit/ac1242a))

***

#### v1.0.0 `June 22, 2016`

***
#### v0.0.4 `May 13, 2016`
- **[FIX]** Fixed BE viewhelper IconAndTitleLinkForRecord ([b0ac990](https://github.com/t3kit/t3kit_extension_tools/commit/b0ac990))

#### v0.0.3 `May 10, 2016`
- **[DOC]** add Readme ([b9d96c2](https://github.com/t3kit/t3kit_extension_tools/commit/b9d96c2))
- **[CHORE]** add changelog file ([af8440e](https://github.com/t3kit/t3kit_extension_tools/commit/af8440e))
- **[FEATURE]** Possibility to override iconselector in pages ([153723f](https://github.com/t3kit/t3kit_extension_tools/commit/153723f))
- **[FIX]** missing icons due to duplicate order property, no localizations of items added with pagets. ([8bed41d](https://github.com/t3kit/t3kit_extension_tools/commit/8bed41d))
- **[FIX]** cssFile can be overriden by page ts ([5610c7e](https://github.com/t3kit/t3kit_extension_tools/commit/5610c7e))

