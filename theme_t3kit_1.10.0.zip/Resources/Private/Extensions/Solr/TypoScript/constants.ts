
[applicationContext = Development/Docker, Production/Docker]
    themes.configuration.features.solrBaseCoreName = core
[global]
