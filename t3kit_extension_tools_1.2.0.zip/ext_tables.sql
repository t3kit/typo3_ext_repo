#
# Modifying pages table
#
CREATE TABLE pages (
  tx_t3kitextensiontools_fixed_post_var_conf varchar(100) DEFAULT '0' NOT NULL
);