plugin.tx_news.settings.defaultDetailPid = {$themes.configuration.features.newsDefaultDetailPid}
plugin.tx_news.settings.detail.media.image.lightbox.class = {$styles.content.textmedia.linkWrap.lightboxCssClass}

plugin.tx_news.settings.newsCarousel.cropMaxCharacters = 136

plugin.tx_news.settings.card.cropMaxCharacters = 200

plugin.tx_news.settings.simpleList.cropMaxCharacters = 280

plugin.tx_news.settings.timeline.cropMaxCharacters = 500

plugin.tx_news.settings.list.media.dummyImage = typo3conf/ext/theme_t3kit/Resources/Public/Extensions/News/images/no_image.png
